//>>built
define("dijit/form/nls/ru/ComboBox",({previousMessage:"Предыдущие варианты",nextMessage:"Следующие варианты"}));
